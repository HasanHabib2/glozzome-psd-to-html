$('.slider').slick({
    Infinity: true,
    slideToShow: 1,
    slideToScroll: 1
});